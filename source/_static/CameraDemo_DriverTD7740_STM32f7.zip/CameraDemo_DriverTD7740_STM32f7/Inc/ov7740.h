/**
  ******************************************************************************
  * @file    ov7740.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    25-June-2015
  * @brief   This file contains all the functions prototypes for the ov7740.c
  *          driver.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __OV7740_H
#define __OV7740_H

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
#include "../Common/camera.h"
   
/** @addtogroup BSP
  * @{
  */ 

/** @addtogroup Components
  * @{
  */ 
  
/** @addtogroup ov7740
  * @{
  */

/** @defgroup OV7740_Exported_Types
  * @{
  */
     
/**
  * @}
  */ 

/** @defgroup OV7740_Exported_Constants
  * @{
  */
/** 
  * @brief  OV7740 ID
  */  
//#define  OV7740_ID    0x96

 //HACK
#define  OV7740_ID    0x77
/** 
  * @brief  OV7740 Registers
  */

/* OV7740 Registers definition */
#define OV7740_SENSOR_PIDH              0x0A
#define OV7740_SENSOR_PIDL              0x0B
#define OV7740_SENSOR_COM7              0x12
#define OV7740_SENSOR_SDE               0xda
#define OV7740_SENSOR_UREG              0xdf
#define OV7740_SENSOR_VREG              0xe0

#define OV7740_SENSOR_BRTN              0xe3
#define OV7740_SENSOR_BRTN2             0xe4
#define OV7740_SENSOR_CNST1             0xe2
#define OV7740_SENSOR_CNST2             0x57

 /**
  * @brief  OV7740 Features Parameters
  */
 #define OV7740_SENSOR_BRTNCNST_CTRL_VAL	0x04	  /* Allow brightness/contrast changes  */

 #define OV7740_BRIGHTNESS_LEVEL0        0x0e20     /* Brightness level -2         */
 #define OV7740_BRIGHTNESS_LEVEL1        0x0e10     /* Brightness level -1         */
 #define OV7740_BRIGHTNESS_LEVEL2        0x0600     /* Brightness level 0          */
 #define OV7740_BRIGHTNESS_LEVEL3        0x0610     /* Brightness level +1         */
 #define OV7740_BRIGHTNESS_LEVEL4        0x0620     /* Brightness level +2         */

 #define OV7740_BLACK_WHITE_BW           0x00000000808024  /* Black and white effect      */
 #define OV7740_BLACK_WHITE_NEGATIVE     0x00000000808044  /* Negative effect             */
 #define OV7740_BLACK_WHITE_BW_NEGATIVE  0x00000000808064  /* BW and Negative effect      */
 #define OV7740_BLACK_WHITE_NORMAL       0x00000000808004  /* Normal effect               */

 #define OV7740_CONTRAST_LEVEL0          0x18     /* Contrast level -2           */
 #define OV7740_CONTRAST_LEVEL1          0x1c     /* Contrast level -1           */
 #define OV7740_CONTRAST_LEVEL2          0x20     /* Contrast level 0            */
 #define OV7740_CONTRAST_LEVEL3          0x24     /* Contrast level +1           */
 #define OV7740_CONTRAST_LEVEL4          0x28     /* Contrast level +2           */

 #define OV7740_COLOR_EFFECT_NONE        0x00000000808004  /* No color effect             */
 #define OV7740_COLOR_EFFECT_ANTIQUE     0x00000000a0401c  /* Sepia effect              */
 #define OV7740_COLOR_EFFECT_BLUE        0x0000000040a01c  /* Blue effect                 */
 #define OV7740_COLOR_EFFECT_GREEN       0x0000000060601c  /* Green effect                */
 #define OV7740_COLOR_EFFECT_RED         0x00000000c0801c  /* Red effect                  */
 /**
   * @}
   */


  
/** @defgroup OV7740_Exported_Functions
  * @{
  */ 
void     ov7740_Init(uint16_t DeviceAddr, uint32_t resolution);
void     ov7740_Config(uint16_t DeviceAddr, uint32_t feature, uint32_t value, uint32_t BR_value);
uint16_t ov7740_ReadID(uint16_t DeviceAddr);

void     CAMERA_IO_Init(void);
void     CAMERA_IO_Write(uint8_t addr, uint8_t reg, uint8_t value);
uint8_t  CAMERA_IO_Read(uint8_t addr, uint8_t reg);
void     CAMERA_Delay(uint32_t delay);

/* CAMERA driver structure */
extern CAMERA_DrvTypeDef   ov7740_drv;
/**
  * @}
  */    
#ifdef __cplusplus
}
#endif

#endif /* __OV7740_H */
/**
  * @}
  */ 

/**
  * @}
  */ 

/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
